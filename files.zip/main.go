package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"time"
)

type Transaction struct {
	ID       string  `json:"id"`
	Type     string  `json:"type"` // "income" or "expense"
	Category string  `json:"category"`
	Amount   float64 `json:"amount"`
	Note     string  `json:"note"`
	Date     string  `json:"date"`
}

type Budget struct {
	Category string  `json:"category"`
	Limit    float64 `json:"limit"`
}

type Store struct {
	Transactions []Transaction `json:"transactions"`
	Budgets      []Budget      `json:"budgets"`
}

const dataFile = "data/store.json"

func loadStore() Store {
	f, err := os.ReadFile(dataFile)
	if err != nil {
		return Store{}
	}
	var s Store
	json.Unmarshal(f, &s)
	return s
}

func saveStore(s Store) error {
	b, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(dataFile, b, 0644)
}

func generateID() string {
	return fmt.Sprintf("%d", time.Now().UnixNano())
}

func enableCORS(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Content-Type", "application/json")
}

func main() {
	os.MkdirAll("data", 0755)

	// Seed sample data if empty
	s := loadStore()
	if len(s.Transactions) == 0 {
		now := time.Now()
		s.Transactions = []Transaction{
			{ID: "1", Type: "income", Category: "Salary", Amount: 5000, Note: "Monthly salary", Date: now.AddDate(0, 0, -25).Format("2006-01-02")},
			{ID: "2", Type: "expense", Category: "Food", Amount: 350, Note: "Groceries", Date: now.AddDate(0, 0, -20).Format("2006-01-02")},
			{ID: "3", Type: "expense", Category: "Transport", Amount: 120, Note: "Fuel", Date: now.AddDate(0, 0, -15).Format("2006-01-02")},
			{ID: "4", Type: "income", Category: "Freelance", Amount: 800, Note: "Design project", Date: now.AddDate(0, 0, -10).Format("2006-01-02")},
			{ID: "5", Type: "expense", Category: "Utilities", Amount: 200, Note: "Electricity & water", Date: now.AddDate(0, 0, -5).Format("2006-01-02")},
			{ID: "6", Type: "expense", Category: "Food", Amount: 180, Note: "Dining out", Date: now.AddDate(0, 0, -2).Format("2006-01-02")},
		}
		s.Budgets = []Budget{
			{Category: "Food", Limit: 600},
			{Category: "Transport", Limit: 300},
			{Category: "Utilities", Limit: 250},
			{Category: "Entertainment", Limit: 150},
		}
		saveStore(s)
	}

	mux := http.NewServeMux()

	// Serve static files
	mux.Handle("/", http.FileServer(http.Dir("static")))

	// API: Get all data
	mux.HandleFunc("/api/data", func(w http.ResponseWriter, r *http.Request) {
		enableCORS(w)
		s := loadStore()
		json.NewEncoder(w).Encode(s)
	})

	// API: Add transaction
	mux.HandleFunc("/api/transactions", func(w http.ResponseWriter, r *http.Request) {
		enableCORS(w)
		if r.Method == http.MethodOptions {
			w.Header().Set("Access-Control-Allow-Methods", "POST, DELETE")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
			return
		}
		if r.Method == http.MethodPost {
			var t Transaction
			json.NewDecoder(r.Body).Decode(&t)
			t.ID = generateID()
			if t.Date == "" {
				t.Date = time.Now().Format("2006-01-02")
			}
			s := loadStore()
			s.Transactions = append(s.Transactions, t)
			saveStore(s)
			json.NewEncoder(w).Encode(t)
		} else if r.Method == http.MethodDelete {
			id := r.URL.Query().Get("id")
			s := loadStore()
			newT := s.Transactions[:0]
			for _, t := range s.Transactions {
				if t.ID != id {
					newT = append(newT, t)
				}
			}
			s.Transactions = newT
			saveStore(s)
			json.NewEncoder(w).Encode(map[string]string{"status": "deleted"})
		}
	})

	// API: Budgets
	mux.HandleFunc("/api/budgets", func(w http.ResponseWriter, r *http.Request) {
		enableCORS(w)
		if r.Method == http.MethodOptions {
			w.Header().Set("Access-Control-Allow-Methods", "POST, PUT")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
			return
		}
		if r.Method == http.MethodPost {
			var b Budget
			json.NewDecoder(r.Body).Decode(&b)
			s := loadStore()
			updated := false
			for i, existing := range s.Budgets {
				if existing.Category == b.Category {
					s.Budgets[i].Limit = b.Limit
					updated = true
					break
				}
			}
			if !updated {
				s.Budgets = append(s.Budgets, b)
			}
			saveStore(s)
			json.NewEncoder(w).Encode(b)
		}
	})

	// API: Summary stats
	mux.HandleFunc("/api/summary", func(w http.ResponseWriter, r *http.Request) {
		enableCORS(w)
		s := loadStore()
		monthStr := r.URL.Query().Get("month")
		if monthStr == "" {
			monthStr = time.Now().Format("2006-01")
		}

		var totalIncome, totalExpense float64
		categoryExpense := map[string]float64{}

		for _, t := range s.Transactions {
			if len(t.Date) >= 7 && t.Date[:7] == monthStr {
				if t.Type == "income" {
					totalIncome += t.Amount
				} else {
					totalExpense += t.Amount
					categoryExpense[t.Category] += t.Amount
				}
			}
		}

		// Budget status
		type BudgetStatus struct {
			Category string  `json:"category"`
			Limit    float64 `json:"limit"`
			Spent    float64 `json:"spent"`
			Percent  float64 `json:"percent"`
		}
		budgetStatus := []BudgetStatus{}
		for _, b := range s.Budgets {
			spent := categoryExpense[b.Category]
			pct := 0.0
			if b.Limit > 0 {
				pct, _ = strconv.ParseFloat(fmt.Sprintf("%.1f", (spent/b.Limit)*100), 64)
			}
			budgetStatus = append(budgetStatus, BudgetStatus{b.Category, b.Limit, spent, pct})
		}

		json.NewEncoder(w).Encode(map[string]interface{}{
			"totalIncome":     totalIncome,
			"totalExpense":    totalExpense,
			"balance":         totalIncome - totalExpense,
			"categoryExpense": categoryExpense,
			"budgetStatus":    budgetStatus,
		})
	})

	port := "8080"
	fmt.Printf("Server running at http://localhost:%s\n", port)
	log.Fatal(http.ListenAndServe(":"+port, mux))
}
