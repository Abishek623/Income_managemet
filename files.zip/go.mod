module income-manager

go 1.21
