# 💰 FinFlow — Personal Income Manager

A full-stack income management web app built with **Go** (backend) and **HTML/CSS/JS** (frontend).

## Features

- ✅ Add & track income and expenses
- 📊 Dashboard with doughnut chart (expense breakdown)
- 🎯 Monthly budget goals with progress bars
- 📋 Transaction history with delete support
- 💾 JSON-based data persistence (no database needed)
- 📱 Responsive design

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Go (`net/http`) |
| Frontend | HTML5, CSS3, Vanilla JS |
| Charts | Chart.js |
| Storage | JSON file |

## Project Structure

```
income-manager/
├── main.go          # Go server + REST API
├── go.mod           # Go module definition
├── static/
│   └── index.html   # Frontend (single-page app)
└── data/
    └── store.json   # Data storage (auto-created)
```

## Getting Started

### Prerequisites
- [Go 1.21+](https://golang.org/dl/)

### Run Locally

```bash
git clone https://github.com/YOUR_USERNAME/income-manager.git
cd income-manager
go run main.go
```

Then open [http://localhost:8080](http://localhost:8080) in your browser.

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/data` | Fetch all transactions & budgets |
| POST | `/api/transactions` | Add a transaction |
| DELETE | `/api/transactions?id=ID` | Delete a transaction |
| POST | `/api/budgets` | Set/update a budget |
| GET | `/api/summary?month=YYYY-MM` | Get monthly summary |

## Screenshots

> Dashboard with income/expense stats, charts, and budget progress.

## Deployment

You can deploy this for free on [Render](https://render.com):
1. Push to GitHub
2. New Web Service → connect repo
3. Build command: `go build -o app`
4. Start command: `./app`

## License

MIT
